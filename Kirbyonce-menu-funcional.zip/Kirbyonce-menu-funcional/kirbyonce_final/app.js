// esto lo hice para tener a la mano los elementos del HTML
const player = document.getElementById('player');
const beyonce = document.getElementById('beyonce');
const gameArea = document.getElementById('game-area');

// esto lo hice para tener las partes del menú
const overlay = document.getElementById('menu-overlay');
const abrirMenu = document.getElementById('abrirMenu');
const cerrarMenu = document.getElementById('cerrarMenu');
const reiniciar = document.getElementById('reiniciar');
const filas = document.querySelectorAll('.fila');
const controlTitulo = document.getElementById('control-titulo');
const controlContenido = document.getElementById('control-contenido');

// aquí guardo dónde empieza cada uno
let playerPosition = { x: 100, y: 100 };
let beyoncePosition = { x: 300, y: 300 };

// esto lo hice para que el menú pueda cambiar estas cosas mientras juego
let playerSpeed = 40;
let beyonceSpeed = 1;
let beyonceSize = 50;

// esto lo hice para saber si el menú está abierto (el juego se pausa) y cuál opción tengo elegida
let menuAbierto = false;
let seleccion = 0;
const PLAYER_SIZE = 50;

// aquí tengo las 5 opciones del menú, en el mismo orden que mi imagen
// cada una guarda su valor, su valor inicial y qué hacer cuando cambia
const opciones = [
    {
        nombre: 'Velocidad del jugador', tipo: 'rango',
        min: 10, max: 100, paso: 5, inicial: 40, valor: 40,
        aplicar(v) { playerSpeed = v; }
    },
    {
        nombre: 'Velocidad de Kirbyoncé', tipo: 'rango',
        min: 0.5, max: 5, paso: 0.5, inicial: 1, valor: 1,
        aplicar(v) { beyonceSpeed = v; }
    },
    {
        nombre: 'Color de fondo', tipo: 'color',
        colores: ['#f0f0f0', '#ffd6e7', '#d6f5ff', '#fff3b0', '#d9ffd6', '#2b2b3a'],
        inicial: '#f0f0f0', valor: '#f0f0f0',
        aplicar(v) { gameArea.style.backgroundColor = v; }
    },
    {
        nombre: 'Tamaño de Kirbyoncé', tipo: 'rango',
        min: 30, max: 100, paso: 10, inicial: 50, valor: 50,
        aplicar(v) {
            beyonceSize = v;
            beyonce.style.width = v + 'px';
            beyonce.style.height = v + 'px';
            beyoncePosition.x = Math.min(beyoncePosition.x, gameArea.clientWidth - v);
            beyoncePosition.y = Math.min(beyoncePosition.y, gameArea.clientHeight - v);
            updatePositions();
        }
    },
    {
        nombre: 'Color del jugador', tipo: 'color',
        colores: ['#0000ff', '#e63946', '#2a9d8f', '#f4a261', '#9b5de5', '#000000'],
        inicial: '#0000ff', valor: '#0000ff',
        aplicar(v) { player.style.backgroundColor = v; }
    }
];

// esto lo hice para guardar los controles que dibujo abajo del menú y poder actualizarlos
let controles = {};

// movimiento del jugador y teclas 

window.addEventListener('keydown', (event) => {
    // esto lo hice para abrir y cerrar el menú con Esc
    if (event.key === 'Escape') {
        if (menuAbierto) cerrarElMenu(); else abrirElMenu();
        return;
    }

    // esto lo hice para que las flechas no muevan sliders ni la página
    if (event.key.startsWith('Arrow')) {
        event.preventDefault();
    }

    // si el menú está abierto las teclas son para el menú, no para el jugador
    if (menuAbierto) {
        teclasDelMenu(event);
        return;
    }

    switch (event.key) {
        case 'ArrowUp':
            if (playerPosition.y > 0) playerPosition.y -= playerSpeed;
            break;
        case 'ArrowDown':
            if (playerPosition.y < gameArea.clientHeight - 50) playerPosition.y += playerSpeed;
            break;
        case 'ArrowLeft':
            if (playerPosition.x > 0) playerPosition.x -= playerSpeed;
            break;
        case 'ArrowRight':
            if (playerPosition.x < gameArea.clientWidth - 50) playerPosition.x += playerSpeed;
            break;
    }

    // esto lo hice porque con velocidades grandes el jugador se podía salir del cuadro y no se ve estetico
    playerPosition.x = Math.max(0, Math.min(playerPosition.x, gameArea.clientWidth - PLAYER_SIZE));
    playerPosition.y = Math.max(0, Math.min(playerPosition.y, gameArea.clientHeight - PLAYER_SIZE));

    updatePositions();
});

//parte de Kirbyoncé 

// esto lo hice para que Kirbyoncé siempre vaya persiguiendo al jugador
function moveBeyonce() {
    // se acerca al jugador sin pasarse de su posición
    const dx = playerPosition.x - beyoncePosition.x;
    const dy = playerPosition.y - beyoncePosition.y;
    beyoncePosition.x += Math.sign(dx) * Math.min(Math.abs(dx), beyonceSpeed);
    beyoncePosition.y += Math.sign(dy) * Math.min(Math.abs(dy), beyonceSpeed);
    beyoncePosition.x = Math.max(0, Math.min(beyoncePosition.x, gameArea.clientWidth - beyonceSize));
    beyoncePosition.y = Math.max(0, Math.min(beyoncePosition.y, gameArea.clientHeight - beyonceSize));

    updatePositions();
    checkCollision();
}

// esto lo hice para dibujar a los dos en su posición actual en la pantalla
function updatePositions() {
    player.style.transform = `translate(${playerPosition.x}px, ${playerPosition.y}px)`;
    beyonce.style.transform = `translate(${beyoncePosition.x}px, ${beyoncePosition.y}px)`;
}

// esto lo hice para ver si Kirbyoncé ya alcanzó al jugador
// uso el tamaño de Kirbyoncé para saber qué tan cerca es "alcanzar"
function checkCollision() {
    if (playerPosition.x < beyoncePosition.x + beyonceSize &&
        playerPosition.x + PLAYER_SIZE > beyoncePosition.x &&
        playerPosition.y < beyoncePosition.y + beyonceSize &&
        playerPosition.y + PLAYER_SIZE > beyoncePosition.y) {
        alert('¡Beyoncé te atrapó!');

        playerPosition = { x: 100, y: 100 };
        beyoncePosition = { x: 300, y: 300 };
    }
}

//  menú de config 

// esto lo hice para abrir el menú (el juego se queda pausado mientras está abierto)
function abrirElMenu() {
    menuAbierto = true;
    overlay.hidden = false;
    mostrarOpcion(seleccion);
}

// esto lo hice para cerrar el menú y seguir jugando
function cerrarElMenu() {
    menuAbierto = false;
    overlay.hidden = true;
    if (document.activeElement) document.activeElement.blur(); // para que la barra espaciadora no le dé clic a un botón
}

// esto lo hice para marcar la opción que elegí y dibujar su control abajo
function mostrarOpcion(i) {
    seleccion = i;
    const op = opciones[i];

    filas.forEach((fila, n) => fila.classList.toggle('seleccionada', n === i));

    controlTitulo.textContent = (i + 1) + '. ' + op.nombre;
    controlContenido.innerHTML = '';
    controles = {};

    if (op.tipo === 'rango') {
        // slider con el número al lado
        const slider = document.createElement('input');
        slider.type = 'range';
        slider.min = op.min;
        slider.max = op.max;
        slider.step = op.paso;
        slider.addEventListener('input', () => cambiarValor(i, Number(slider.value)));

        const numero = document.createElement('span');

        controlContenido.appendChild(slider);
        controlContenido.appendChild(numero);
        controles = { slider, numero, muestras: [] };
    } else {
        // circulitos de colores y además el selector de color por si quiero otro
        controles = { muestras: [] };
        op.colores.forEach((color) => {
            const muestra = document.createElement('button');
            muestra.className = 'muestra';
            muestra.style.backgroundColor = color;
            muestra.addEventListener('click', () => cambiarValor(i, color));
            controlContenido.appendChild(muestra);
            controles.muestras.push({ muestra, color });
        });

        const selector = document.createElement('input');
        selector.type = 'color';
        selector.addEventListener('input', () => cambiarValor(i, selector.value));
        controlContenido.appendChild(selector);
        controles.selector = selector;
    }

    actualizarControl();
}

// esto lo hice para que el control refleje el valor actual sin tener que volver a dibujarlo
function actualizarControl() {
    const op = opciones[seleccion];

    if (op.tipo === 'rango') {
        controles.slider.value = op.valor;
        controles.numero.textContent = op.valor;
    } else {
        controles.selector.value = op.valor;
        controles.muestras.forEach((m) => {
            m.muestra.classList.toggle('activa', m.color === op.valor);
        });
    }
}

// esto lo hice para guardar el valor nuevo, aplicarlo al juego y actualizar el control
function cambiarValor(i, valor) {
    opciones[i].valor = valor;
    opciones[i].aplicar(valor);
    actualizarControl();
}

// esto lo hice para manejar el menú con el teclado como en un videojuego
// arriba/abajo cambia de opción, izquierda/derecha cambia el valor, y 1-5 va directo a una opción
function teclasDelMenu(event) {
    if (event.key === 'ArrowUp') {
        mostrarOpcion((seleccion + opciones.length - 1) % opciones.length);
    } else if (event.key === 'ArrowDown') {
        mostrarOpcion((seleccion + 1) % opciones.length);
    } else if (event.key === 'ArrowLeft') {
        ajustarValor(-1);
    } else if (event.key === 'ArrowRight') {
        ajustarValor(1);
    } else if (event.key >= '1' && event.key <= String(opciones.length)) {
        mostrarOpcion(Number(event.key) - 1);
    }
}

// esto lo hice para subir o bajar el valor de la opción elegida (dir es 1 o -1)
function ajustarValor(dir) {
    const op = opciones[seleccion];

    if (op.tipo === 'rango') {
        let nuevo = op.valor + dir * op.paso;
        nuevo = Math.max(op.min, Math.min(op.max, nuevo));
        cambiarValor(seleccion, Math.round(nuevo * 10) / 10);
    } else {
        // en los colores recorro la lista de circulitos
        let n = op.colores.indexOf(op.valor);
        n = (n + dir + op.colores.length) % op.colores.length;
        cambiarValor(seleccion, op.colores[n]);
    }
}

// esto lo hice para que cada renglón de mi imagen sea un botón
filas.forEach((fila, n) => {
    fila.addEventListener('click', () => mostrarOpcion(n));
});

// esto lo hice para regresar todo a como estaba al inicio
reiniciar.addEventListener('click', () => {
    opciones.forEach((op) => {
        op.valor = op.inicial;
        op.aplicar(op.inicial);
    });
    actualizarControl();
    reiniciar.blur();
});

abrirMenu.addEventListener('click', abrirElMenu);
cerrarMenu.addEventListener('click', cerrarElMenu);

// esto lo hice para que el juego se repita todo el tiempo, pero se pause si el menú está abierto
function gameLoop() {
    if (!menuAbierto) {
        moveBeyonce();
    }
    requestAnimationFrame(gameLoop);
}

// aquí arranco el juego
opciones.forEach(op => op.aplicar(op.valor));
updatePositions();
gameLoop();
